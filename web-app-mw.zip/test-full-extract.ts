import { GoogleGenAI } from '@google/genai';
import { EXTRACT_PROMPT, GEN_CONFIG } from './src/config';
import { validateDesignSpec } from './src/services/validate';
import { renderDesignMd } from './src/services/render';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
const sampleBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

console.log('Testing full extraction on gemini-flash-lite-latest...');
const start = Date.now();
const res = await ai.models.generateContent({
  model: 'gemini-flash-lite-latest',
  contents: [
    {
      role: 'user',
      parts: [
        { text: 'img1' },
        { inlineData: { mimeType: 'image/png', data: sampleBase64 } },
        { text: 'MEASURED PALETTE:\n[{"hex": "#0063E1", "count": 100}, {"hex": "#000000", "count": 300}, {"hex": "#FFFFFF", "count": 200}]' }
      ]
    }
  ],
  config: {
    systemInstruction: EXTRACT_PROMPT,
    temperature: 0,
    responseMimeType: 'application/json',
  }
});

console.log(`Generated in ${Date.now() - start}ms!`);
console.log('Raw text:', res.text?.slice(0, 300));

const parsed = JSON.parse(res.text || '{}');
const validated = validateDesignSpec(parsed);
console.log('Validated successfully?:', validated.success);
if (validated.data) {
  const md = renderDesignMd(validated.data);
  console.log('Markdown generated! Length:', md.length);
  console.log('Markdown title:', validated.data.meta.title);
  console.log('Colors:', validated.data.colors.length);
  console.log('Components:', validated.data.components.length);
}
