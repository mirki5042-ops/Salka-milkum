/**
 * Full-stack Express server for Loupe
 * Handles server-side Gemini API calls securely without exposing keys to the browser
 */
import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { directAiAnalyze, directAiExtract } from './src/services/ai';
import { mapError } from './src/services/errors';

dotenv.config();

const app = express();
const PORT = 3000;

// High limit for base64 screenshots
app.use(express.json({ limit: '50mb' }));

// Health endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'Loupe',
    version: '1.0.0',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    hasApiKey: Boolean(process.env.API_KEY),
    matchingKeys: Object.keys(process.env).filter(k => k.includes('KEY') || k.includes('AI') || k.includes('GEMINI')),
  });
});

// Server-side AI Analyze endpoint
app.post('/api/ai/analyze', async (req, res) => {
  try {
    const { images } = req.body;
    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ code: 'network', message: 'No images provided' });
    }

    const result = await directAiAnalyze(images);
    return res.json(result);
  } catch (err: any) {
    const mapped = mapError(err);
    console.error('AI analyze error:', err?.message || err);
    return res.status(500).json({ code: mapped.code, message: mapped.message });
  }
});

// Server-side AI Extract endpoint
app.post('/api/ai/extract', async (req, res) => {
  try {
    const { images, measurements } = req.body;
    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ code: 'network', message: 'No images provided' });
    }

    const spec = await directAiExtract(images, measurements || { palette: [], dimensions: [] });
    return res.json(spec);
  } catch (err: any) {
    const mapped = mapError(err);
    console.error('AI extract error:', err?.message || err);
    return res.status(500).json({ code: mapped.code, message: mapped.message });
  }
});

// Mount Vite or serve static
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve('dist/index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Loupe server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
