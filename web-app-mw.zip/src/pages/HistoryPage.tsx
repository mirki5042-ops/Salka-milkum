/**
 * S8 History Screen
 * Document 2, Section 4.7
 */
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Trash2, ArrowRight } from 'lucide-react';
import { listResults, deleteResult } from '../storage/local';
import { Result } from '../types';
import { Dialog } from '../components/Dialog';
import { useToast } from '../components/Toast';

export const HistoryPage: React.FC = () => {
  const { showToast } = useToast();
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(true);
  const [itemToDelete, setItemToDelete] = useState<Result | null>(null);

  const loadHistory = async () => {
    setLoading(true);
    const list = await listResults();
    setResults(list);
    setLoading(false);
  };

  useEffect(() => {
    loadHistory();
  }, []);

  const handleDeleteConfirm = async () => {
    if (!itemToDelete) return;
    await deleteResult(itemToDelete.id);
    showToast('Deleted design result');
    setItemToDelete(null);
    loadHistory();
  };

  return (
    <div className="max-w-[1200px] mx-auto px-6 py-12 flex flex-col gap-8 text-left">
      <div className="flex flex-col gap-1">
        <h1 className="text-3xl font-normal text-white tracking-[-0.027em]">
          History
        </h1>
        <p className="text-sm text-[#858585]">
          All extracted design systems saved in your browser’s local storage.
        </p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className="h-48 rounded-[16px] bg-[#0d0d0d] inset-border animate-pulse"
            />
          ))}
        </div>
      ) : results.length === 0 ? (
        <div className="py-24 text-center flex flex-col items-center gap-4">
          <p className="text-base text-[#858585]">No saved design results yet.</p>
          <Link
            to="/generate"
            className="bg-[#0063e1] hover:bg-[#0052be] text-white text-sm font-medium px-6 py-2.5 rounded-[59px] transition-colors"
          >
            Generate your first design.md
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {results.map((res) => {
            const formattedDate = new Date(res.createdAt).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
            });
            const allTags = [
              ...(res.tags.industry || []),
              ...(res.tags.style || []),
              ...(res.tags.sections || []),
            ].slice(0, 3);

            return (
              <div
                key={res.id}
                className="group relative bg-[#0d0d0d] hover:bg-[#141414] rounded-[16px] inset-border p-4 flex flex-col gap-3 transition-all"
              >
                <Link
                  to={`/result/${res.id}`}
                  data-testid={`history-card-${res.id}`}
                  className="flex flex-col gap-3 flex-1"
                >
                  {/* Thumbnail */}
                  <div className="w-full h-36 rounded-[12px] bg-[#040910] inset-border overflow-hidden flex items-center justify-center p-2">
                    {res.images[0]?.thumbDataUrl || res.images[0]?.dataUrl ? (
                      <img
                        src={res.images[0].thumbDataUrl || res.images[0].dataUrl}
                        alt={res.title}
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <span className="text-xs text-[#858585] font-mono">No image</span>
                    )}
                  </div>

                  <h3 className="text-sm font-medium text-white line-clamp-1 group-hover:text-white">
                    {res.title}
                  </h3>

                  <div className="flex flex-wrap gap-1 mt-auto">
                    {allTags.map((t) => (
                      <span
                        key={t}
                        className="bg-[#1f1f1f] text-[#858585] text-[11px] font-mono px-2 py-0.5 rounded-[4px]"
                      >
                        {t}
                      </span>
                    ))}
                  </div>

                  <div className="text-[11px] text-[#858585] font-mono pt-2 border-t border-[rgba(255,255,255,0.06)] flex justify-between">
                    <span>{formattedDate}</span>
                    <span>{res.images.length} images</span>
                  </div>
                </Link>

                {/* Delete Button */}
                <button
                  type="button"
                  data-testid={`history-delete-${res.id}`}
                  onClick={() => setItemToDelete(res)}
                  aria-label="Delete result"
                  className="absolute top-6 right-6 p-1.5 bg-[#1f1f1f]/80 hover:bg-[#2b2c2e] text-[#858585] hover:text-white rounded-full inset-border transition-colors cursor-pointer opacity-0 group-hover:opacity-100 focus:opacity-100"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      <Dialog
        isOpen={itemToDelete !== null}
        onClose={() => setItemToDelete(null)}
        title="Delete Design Result"
        description={`Are you sure you want to delete "${itemToDelete?.title}"? This cannot be undone.`}
      >
        <div className="flex justify-end gap-3 mt-4">
          <button
            type="button"
            onClick={() => setItemToDelete(null)}
            className="px-4 py-2 text-xs text-[#858585] hover:text-white font-medium rounded-[59px] inset-border bg-[#1f1f1f] cursor-pointer"
          >
            Keep
          </button>
          <button
            type="button"
            data-testid="confirm-delete"
            onClick={handleDeleteConfirm}
            className="px-4 py-2 text-xs text-white font-medium rounded-[59px] inset-border bg-[#2b2c2e] hover:bg-[#36383b] cursor-pointer"
          >
            Delete
          </button>
        </div>
      </Dialog>
    </div>
  );
};
