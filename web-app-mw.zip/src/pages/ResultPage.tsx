/**
 * S7 Result Screen
 * Document 2, Section 4.6, 5.11 & 5.12
 */
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Copy, Download, FileText, Share2, Loader2, ArrowRight } from 'lucide-react';
import { getResult, getSiteQueue, saveResult, setSiteQueue } from '../storage/local';
import { createShare, setPublic, getShare } from '../storage/remote';
import { Result, SiteGroup } from '../types';
import { MarkdownView } from '../components/MarkdownView';
import { RawView } from '../components/RawView';
import { Lightbox } from '../components/Lightbox';
import { DebugPanel } from '../components/DebugPanel';
import { useToast } from '../components/Toast';
import { slug } from '../services/render';
import { compressImage } from '../services/compress';
import { COVER_MAX_BYTES, COVER_WIDTH } from '../config';
import { useRunStore } from '../store/runStore';

export const ResultPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'preview' | 'raw'>('preview');

  // Sharing & Publish state
  const [isSharing, setIsSharing] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [isPublic, setIsPublic] = useState(false);

  // Lightbox state
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Site Queue ("Next up")
  const [siteQueue, setLocalSiteQueue] = useState<SiteGroup[]>([]);

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      if (!id) return;
      setLoading(true);
      const res = await getResult(id);
      if (isMounted) {
        if (res) {
          setResult(res);
          // Check if already published
          if (res.shareId) {
            const share = await getShare(res.shareId);
            if (share && share.visibility === 'public') {
              setIsPublic(true);
            }
          }
        }
        const queue = await getSiteQueue();
        setLocalSiteQueue(queue);
        setLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, [id]);

  const handleCopy = async () => {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.markdown);
      showToast('Copied to clipboard');
    } catch {
      showToast('Failed to copy to clipboard');
    }
  };

  const handleDownload = () => {
    if (!result) return;
    const blob = new Blob([result.markdown], { type: 'text/markdown;charset=utf-8' });
    const filename = `${slug(result.title)}-design.md`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`Downloaded ${filename}`);
  };

  const handleExportPdf = () => {
    setActiveTab('preview');
    // Allow React state to flush tab before triggering print
    setTimeout(() => {
      window.print();
    }, 150);
  };

  const handleShare = async () => {
    if (!result) return;
    setIsSharing(true);

    try {
      let shareId = result.shareId;
      if (!shareId) {
        // Create cover thumbnail
        let coverDataUrl = result.images[0]?.thumbDataUrl || '';
        try {
          const resp = await fetch(result.images[0]?.dataUrl || coverDataUrl);
          const blob = await resp.blob();
          const comp = await compressImage(blob, { maxSide: COVER_WIDTH, maxBytes: COVER_MAX_BYTES });
          coverDataUrl = comp.dataUrl;
        } catch (e) {
          console.warn('Cover compression fallback:', e);
        }

        shareId = await createShare(result, coverDataUrl, result.images);
        const updated = { ...result, shareId };
        await saveResult(updated);
        setResult(updated);
      }

      const shareUrl = `${window.location.origin}/s/${shareId}`;
      await navigator.clipboard.writeText(shareUrl);
      showToast(`Share link copied: ${shareUrl}`);
    } catch (err) {
      console.error(err);
      showToast('Could not create share link');
    } finally {
      setIsSharing(false);
    }
  };

  const handleTogglePublish = async () => {
    if (!result) return;
    setIsPublishing(true);
    const nextState = !isPublic;

    try {
      let shareId = result.shareId;
      if (!shareId) {
        let coverDataUrl = result.images[0]?.thumbDataUrl || '';
        try {
          const resp = await fetch(result.images[0]?.dataUrl || coverDataUrl);
          const blob = await resp.blob();
          const comp = await compressImage(blob, { maxSide: COVER_WIDTH, maxBytes: COVER_MAX_BYTES });
          coverDataUrl = comp.dataUrl;
        } catch {}

        shareId = await createShare(result, coverDataUrl, result.images);
        const updated = { ...result, shareId };
        await saveResult(updated);
        setResult(updated);
      }

      await setPublic(shareId, nextState);
      setIsPublic(nextState);
      showToast(nextState ? 'Published to community library' : 'Removed from public library');
    } catch (err) {
      console.error(err);
      showToast('Failed to update library publication');
    } finally {
      setIsPublishing(false);
    }
  };

  const handleContinueQueue = async (site: SiteGroup) => {
    // Continue extraction for next site in queue
    const remaining = siteQueue.filter((s) => s.id !== site.id);
    await setSiteQueue(remaining);
    setLocalSiteQueue(remaining);
    navigate('/generate');
  };

  if (loading) {
    return (
      <div className="max-w-[1200px] mx-auto px-6 py-24 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#0063e1] animate-spin" />
      </div>
    );
  }

  if (!result) {
    return (
      <div className="max-w-md mx-auto px-6 py-24 text-center flex flex-col gap-4">
        <h2 className="text-xl font-normal text-white">Result Not Found</h2>
        <p className="text-sm text-[#858585]">
          This specification may have been cleared or deleted from your browser history.
        </p>
        <button
          type="button"
          onClick={() => navigate('/generate')}
          className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-sm px-6 py-2.5 rounded-[59px] inset-border transition-colors cursor-pointer self-center"
        >
          Generate New
        </button>
      </div>
    );
  }

  const allTags = [
    ...(result.tags.industry || []),
    ...(result.tags.style || []),
    ...(result.tags.sections || []),
  ];

  const formattedDate = new Date(result.createdAt).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <div className="max-w-[1200px] mx-auto px-6 py-8 flex flex-col gap-6 text-left">
      {/* Banner Next Up (Feature F13) */}
      {siteQueue.length > 0 && (
        <div
          data-testid="banner-next"
          className="bg-[#0d0d0d] rounded-[16px] p-4 inset-border flex items-center justify-between no-print"
        >
          <span className="text-sm text-white">
            Next up: <span className="font-medium text-[#0063e1]">{siteQueue[0].label}</span>.
          </span>
          <button
            type="button"
            onClick={() => handleContinueQueue(siteQueue[0])}
            className="text-xs bg-[#1f1f1f] hover:bg-[#2b2c2e] text-white px-4 py-2 rounded-[59px] inset-border flex items-center gap-1.5 cursor-pointer"
          >
            Extract it now
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Header and Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[rgba(255,255,255,0.08)] pb-6 no-print">
        <div className="flex flex-col gap-2">
          <h1
            data-testid="result-title"
            className="text-2xl font-normal text-white tracking-[-0.027em]"
          >
            {result.title}
          </h1>

          {/* Tags */}
          <div className="flex flex-wrap gap-1.5">
            {allTags.map((tag) => (
              <span
                key={tag}
                className="bg-[#1f1f1f] text-[#858585] text-xs font-mono px-2.5 py-0.5 rounded-[4px]"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            data-testid="btn-copy"
            onClick={handleCopy}
            className="bg-[#0063e1] hover:bg-[#0052be] text-white text-xs font-medium px-4 py-2.5 rounded-[59px] transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            Copy
          </button>
          <button
            type="button"
            data-testid="btn-download"
            onClick={handleDownload}
            className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-xs font-medium px-4 py-2.5 rounded-[59px] inset-border transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Download .md
          </button>
          <button
            type="button"
            data-testid="btn-pdf"
            onClick={handleExportPdf}
            className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-xs font-medium px-4 py-2.5 rounded-[59px] inset-border transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            Export PDF
          </button>
          <button
            type="button"
            data-testid="btn-share"
            onClick={handleShare}
            disabled={isSharing}
            className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-xs font-medium px-4 py-2.5 rounded-[59px] inset-border transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            {isSharing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Share2 className="w-3.5 h-3.5" />}
            Share
          </button>

          {/* Publish to library toggle */}
          <div className="flex items-center gap-2 ml-2 pl-3 border-l border-[rgba(255,255,255,0.08)]">
            <span className="text-xs text-[#858585]">Publish to library</span>
            <button
              type="button"
              data-testid="toggle-publish"
              role="switch"
              aria-checked={isPublic}
              onClick={handleTogglePublish}
              disabled={isPublishing}
              className={`w-10 h-5 flex items-center rounded-full p-0.5 transition-colors cursor-pointer ${
                isPublic ? 'bg-[#0063e1]' : 'bg-[#1f1f1f] inset-border'
              }`}
            >
              <div
                className={`w-4 h-4 bg-white rounded-full transition-transform ${
                  isPublic ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-8 items-start">
        {/* Left Column: Image Previews & Meta */}
        <aside className="flex flex-col gap-4 no-print">
          <span className="text-xs font-mono text-[#858585] uppercase tracking-wider">
            Sources ({result.images.length})
          </span>
          <div className="flex flex-row lg:flex-col gap-3 overflow-x-auto pb-2">
            {result.images.map((img, idx) => (
              <div
                key={idx}
                onClick={() => setLightboxIndex(idx)}
                className="w-28 lg:w-full h-24 lg:h-36 rounded-[12px] bg-[#040910] inset-border overflow-hidden shrink-0 cursor-pointer hover:border-[#0063e1] transition-all group relative flex items-center justify-center p-1"
              >
                <img
                  src={img.thumbDataUrl || img.dataUrl}
                  alt={img.name}
                  className="w-full h-full object-contain group-hover:scale-105 transition-transform"
                />
              </div>
            ))}
          </div>

          <div className="text-xs text-[#858585] font-mono border-t border-[rgba(255,255,255,0.06)] pt-3">
            <div>Created: {formattedDate}</div>
            <div>Images: {result.images.length}</div>
          </div>
        </aside>

        {/* Right Column: Viewer Tabs */}
        <div className="flex flex-col gap-4 min-w-0">
          {/* Tab buttons */}
          <div className="flex items-center gap-1 border-b border-[rgba(255,255,255,0.08)] pb-2 no-print">
            <button
              type="button"
              data-testid="tab-preview"
              onClick={() => setActiveTab('preview')}
              className={`px-4 py-1.5 rounded-[59px] text-xs font-medium transition-colors cursor-pointer ${
                activeTab === 'preview'
                  ? 'bg-[#1f1f1f] text-white inset-border'
                  : 'text-[#858585] hover:text-white'
              }`}
            >
              Preview
            </button>
            <button
              type="button"
              data-testid="tab-raw"
              onClick={() => setActiveTab('raw')}
              className={`px-4 py-1.5 rounded-[59px] text-xs font-medium transition-colors cursor-pointer ${
                activeTab === 'raw'
                  ? 'bg-[#1f1f1f] text-white inset-border'
                  : 'text-[#858585] hover:text-white'
              }`}
            >
              Raw .md
            </button>
          </div>

          {/* Active Tab View */}
          <div className="bg-[#0d0d0d] rounded-[16px] inset-border p-6 print-only-content">
            {activeTab === 'preview' ? (
              <MarkdownView content={result.markdown} />
            ) : (
              <RawView content={result.markdown} />
            )}
          </div>

          {/* Footer instruction banner */}
          <p className="text-xs text-[#858585] italic text-center pt-2 no-print">
            Paste the whole file into your AI builder as the first message.
          </p>
        </div>
      </div>

      {/* Lightbox Overlay */}
      {lightboxIndex !== null && (
        <Lightbox
          images={result.images}
          currentIndex={lightboxIndex}
          isOpen={lightboxIndex !== null}
          onClose={() => setLightboxIndex(null)}
          onPrev={() =>
            setLightboxIndex((prev) =>
              prev === null ? 0 : (prev - 1 + result.images.length) % result.images.length
            )
          }
          onNext={() =>
            setLightboxIndex((prev) =>
              prev === null ? 0 : (prev + 1) % result.images.length
            )
          }
        />
      )}

      {/* Debug Mode Panel */}
      <DebugPanel result={result} />
    </div>
  );
};
