/**
 * TagChip component
 * Document 2 & DESIGN.md
 */
import React from 'react';

interface TagChipProps {
  label: string;
  active?: boolean;
  onClick?: () => void;
  testId?: string;
}

export const TagChip: React.FC<TagChipProps> = ({
  label,
  active = false,
  onClick,
  testId,
}) => {
  return (
    <button
      type="button"
      data-testid={testId}
      onClick={onClick}
      disabled={!onClick}
      className={`px-3 py-1 rounded-[59px] text-xs font-mono tracking-wide transition-all ${
        onClick ? 'cursor-pointer' : 'cursor-default'
      } ${
        active
          ? 'bg-[#0063e1] text-white inset-border'
          : 'bg-[#1f1f1f] text-[#858585] hover:text-white inset-border'
      }`}
    >
      {label}
    </button>
  );
};
