/**
 * Debug mode panel for inspecting raw spec JSON and pipeline timings
 * Document 2, Section 2 (F12)
 */
import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Terminal, X, ChevronDown, ChevronUp } from 'lucide-react';
import { Result } from '../types';

interface DebugPanelProps {
  result?: Result;
}

export const DebugPanel: React.FC<DebugPanelProps> = ({ result }) => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const isDebug = searchParams.get('debug') === '1';

  const [isOpen, setIsOpen] = useState(false);

  if (!isDebug) return null;

  return (
    <div className="fixed bottom-4 left-4 z-40 max-w-lg w-full no-print">
      <div className="bg-[#0d0d0d] border border-[rgba(255,255,255,0.2)] rounded-[12px] p-3 shadow-2xl text-left">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono text-[#0063e1]">
            <Terminal className="w-3.5 h-3.5" />
            <span>DEBUG MODE (?debug=1)</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setIsOpen(!isOpen)}
              className="p-1 text-[#858585] hover:text-white cursor-pointer"
            >
              {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {isOpen && (
          <div className="mt-3 pt-3 border-t border-[rgba(255,255,255,0.08)] flex flex-col gap-2 max-h-80 overflow-y-auto text-xs font-mono">
            {result ? (
              <>
                <div className="flex justify-between text-[#858585]">
                  <span>Result ID:</span>
                  <span className="text-white">{result.id}</span>
                </div>
                <div className="flex justify-between text-[#858585]">
                  <span>Cache Key:</span>
                  <span className="text-white truncate max-w-[280px]" title={result.cacheKey}>
                    {result.cacheKey}
                  </span>
                </div>
                <div className="flex justify-between text-[#858585]">
                  <span>Created:</span>
                  <span className="text-white">{new Date(result.createdAt).toISOString()}</span>
                </div>
                <div className="flex justify-between text-[#858585]">
                  <span>Images:</span>
                  <span className="text-white">{result.images?.length || 0}</span>
                </div>

                <div className="mt-2 text-[#858585]">Raw Spec JSON:</div>
                <pre className="p-2 bg-[#040910] rounded-[6px] text-[10px] text-white overflow-x-auto">
                  {JSON.stringify(result.spec, null, 2)}
                </pre>
              </>
            ) : (
              <p className="text-[#858585]">No active result loaded on this screen.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
