/**
 * Screenshot tile component for upload view
 * Document 2, Section 4.2 & DESIGN.md
 */
import React from 'react';
import { X, ChevronLeft, ChevronRight, AlertCircle } from 'lucide-react';

interface TileProps {
  index: number;
  file: File;
  thumbUrl: string;
  issueReason?: string;
  isFirst: boolean;
  isLast: boolean;
  onRemove: (index: number) => void;
  onMoveEarlier: (index: number) => void;
  onMoveLater: (index: number) => void;
  onDragStart: (e: React.DragEvent, index: number) => void;
  onDragOver: (e: React.DragEvent, index: number) => void;
  onDrop: (e: React.DragEvent, index: number) => void;
}

export const Tile: React.FC<TileProps> = ({
  index,
  file,
  thumbUrl,
  issueReason,
  isFirst,
  isLast,
  onRemove,
  onMoveEarlier,
  onMoveLater,
  onDragStart,
  onDragOver,
  onDrop,
}) => {
  const formatSize = (bytes: number) => {
    if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div
      data-testid={`tile-${index}`}
      draggable
      onDragStart={(e) => onDragStart(e, index)}
      onDragOver={(e) => onDragOver(e, index)}
      onDrop={(e) => onDrop(e, index)}
      className="w-[160px] flex flex-col gap-2 group relative cursor-grab active:cursor-grabbing select-none"
    >
      {/* Thumbnail Container */}
      <div className="w-[160px] h-[160px] bg-[#0d0d0d] rounded-[16px] inset-border overflow-hidden relative flex items-center justify-center p-2 group-hover:border-[rgba(255,255,255,0.2)] transition-all">
        {thumbUrl ? (
          <img
            src={thumbUrl}
            alt={`Screenshot ${index + 1}`}
            className="w-full h-full object-contain rounded-[8px]"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-xs text-[#858585]">
            Loading...
          </div>
        )}

        {/* Order Badge (Top-Left) */}
        <div className="absolute top-2 left-2 bg-[#040910]/90 text-white text-[11px] font-mono px-2 py-0.5 rounded-[4px] inset-border">
          #{index + 1}
        </div>

        {/* Remove Button (Top-Right) */}
        <button
          type="button"
          data-testid={`tile-remove-${index}`}
          onClick={(e) => {
            e.stopPropagation();
            onRemove(index);
          }}
          className="absolute top-2 right-2 p-1 bg-[#1f1f1f]/90 hover:bg-[#2b2c2e] text-[#858585] hover:text-white rounded-full inset-border transition-colors cursor-pointer"
          aria-label={`Remove image ${index + 1}`}
        >
          <X className="w-3.5 h-3.5" />
        </button>

        {/* Accessible Keyboard/Touch Reorder Controls (Bottom Overlay) */}
        <div className="absolute bottom-2 inset-x-2 flex justify-between opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
          <button
            type="button"
            disabled={isFirst}
            onClick={(e) => {
              e.stopPropagation();
              onMoveEarlier(index);
            }}
            aria-label="Move earlier"
            className="p-1 bg-[#1f1f1f]/90 disabled:opacity-30 hover:bg-[#2b2c2e] text-white rounded-full inset-border cursor-pointer disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-3 h-3" />
          </button>
          <button
            type="button"
            disabled={isLast}
            onClick={(e) => {
              e.stopPropagation();
              onMoveLater(index);
            }}
            aria-label="Move later"
            className="p-1 bg-[#1f1f1f]/90 disabled:opacity-30 hover:bg-[#2b2c2e] text-white rounded-full inset-border cursor-pointer disabled:cursor-not-allowed"
          >
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* File Info */}
      <div className="flex flex-col text-left px-1">
        <span className="text-xs text-white font-medium truncate" title={file.name}>
          {file.name}
        </span>
        <span className="text-[11px] text-[#858585] font-mono">
          {formatSize(file.size)}
        </span>
      </div>

      {/* Rejection / Issue Badge (Monochrome treatment per DESIGN.md: Steel bg, white text, Ash border, never red) */}
      {issueReason && (
        <div className="mt-1 bg-[#2b2c2e] border border-[rgba(255,255,255,0.2)] rounded-[6px] p-1.5 flex items-start gap-1 text-[11px] text-white">
          <AlertCircle className="w-3.5 h-3.5 text-white shrink-0 mt-0.5" />
          <span className="leading-tight">{issueReason}</span>
        </div>
      )}
    </div>
  );
};
