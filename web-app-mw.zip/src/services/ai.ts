/**
 * Gemini API handling
 * Document 2, Section 5.5
 * Only file that interacts with @google/genai SDK
 */
import { GoogleGenAI } from '@google/genai';
import {
  GEMINI_MODEL,
  GEMINI_FALLBACK_MODELS,
  GEN_CONFIG,
  ANALYZE_PROMPT,
  EXTRACT_PROMPT,
  CALL_TIMEOUT_MS,
  RETRY_DELAYS_MS,
} from '../config';
import { AppError, mapError } from './errors';
import { AnalyzeResult, DesignSpec, Measurements } from '../types';
import { validateAnalyzeResult, validateDesignSpec } from './validate';

// Lazy initialize SDK on server / Node side
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (aiClient) return aiClient;
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new AppError('ai_config', 'GEMINI_API_KEY environment variable is not set.');
  }
  aiClient = new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
  return aiClient;
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new AppError('cancelled'));
    const timer = setTimeout(resolve, ms);
    signal?.addEventListener('abort', () => {
      clearTimeout(timer);
      reject(new AppError('cancelled'));
    }, { once: true });
  });
}

async function withTimeout<T>(promise: Promise<T>, ms: number, signal?: AbortSignal): Promise<T> {
  let timer: any;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new AppError('network', 'Request timed out')), ms);
  });

  try {
    return await Promise.race([promise, timeoutPromise]);
  } finally {
    clearTimeout(timer);
  }
}

export async function withRetry<T>(
  fn: () => Promise<T>,
  signal: AbortSignal,
  onRetry: (seconds: number, attempt: number) => void
): Promise<T> {
  for (let attempt = 0; ; attempt++) {
    try {
      if (signal.aborted) throw new AppError('cancelled');
      return await withTimeout(fn(), CALL_TIMEOUT_MS, signal);
    } catch (err: any) {
      if (signal.aborted || err?.message?.includes('cancelled')) throw new AppError('cancelled');
      const status = err?.status;
      const retryable = [429, 500, 503, 504].includes(status) || err instanceof TypeError || err?.code === 'quota';
      if (!retryable || attempt >= RETRY_DELAYS_MS.length) {
        throw mapError(err);
      }
      const delaySeconds = RETRY_DELAYS_MS[attempt] / 1000;
      onRetry(delaySeconds, attempt + 1);
      await sleep(RETRY_DELAYS_MS[attempt], signal);
    }
  }
}

/**
 * Cleans potential markdown code blocks around JSON
 */
function cleanJsonResponse(text: string): string {
  let cleaned = text.trim();
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  return cleaned.trim();
}

/**
 * Executes generateContent with automated fallback to alternative flash models on 503/429
 */
async function generateContentWithFallback(
  ai: GoogleGenAI,
  params: {
    contents: any[];
    systemInstruction: string;
  }
) {
  const models = [GEMINI_MODEL, ...(GEMINI_FALLBACK_MODELS || [])];
  let lastError: any = null;

  for (const model of models) {
    try {
      const res = await ai.models.generateContent({
        model,
        contents: params.contents,
        config: {
          systemInstruction: params.systemInstruction,
          ...GEN_CONFIG,
          responseMimeType: 'application/json',
        },
      });
      return res;
    } catch (err: any) {
      lastError = err;
      const status = err?.status;
      const msg = err?.message || '';
      console.warn(`Model ${model} failed (status ${status}): ${msg.slice(0, 100)}. Trying fallback...`);
      if (status === 503 || status === 429 || msg.includes('UNAVAILABLE') || msg.includes('RESOURCE_EXHAUSTED')) {
        continue;
      }
      throw err;
    }
  }

  throw lastError;
}

/**
 * Server-side direct execution using @google/genai SDK
 */
export async function directAiAnalyze(
  images: { base64: string; mimeType: string }[],
  signal?: AbortSignal
): Promise<AnalyzeResult> {
  const ai = getAiClient();
  const parts: any[] = [];

  images.forEach((img, idx) => {
    parts.push({ text: `img${idx + 1}` });
    parts.push({
      inlineData: {
        mimeType: img.mimeType || 'image/jpeg',
        data: img.base64,
      },
    });
  });

  const res = await generateContentWithFallback(ai, {
    contents: [{ role: 'user', parts }],
    systemInstruction: ANALYZE_PROMPT,
  });

  const candidate = res.candidates?.[0];
  if (candidate?.finishReason === 'SAFETY' || res.promptFeedback?.blockReason) {
    throw new AppError('adult_or_unsafe');
  }

  const raw = cleanJsonResponse(res.text || '');
  let parsed: any;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new AppError('unreadable', 'AI response could not be parsed as JSON');
  }

  // If the model determined it's a website but returned no site groups, supply default
  if (parsed.isWebsite !== false && (!parsed.sites || parsed.sites.length === 0)) {
    parsed.isWebsite = true;
    parsed.sites = [
      {
        id: 'site-1',
        label: 'Website Screenshot',
        description: 'Single site extraction',
        sections: ['hero', 'features'],
        imageIndices: images.map((_, i) => i),
      },
    ];
  }

  const validated = validateAnalyzeResult(parsed);
  if (!validated.success || !validated.data) {
    throw new AppError('unreadable', `Analyze schema error: ${validated.errors?.join(', ')}`);
  }

  return validated.data;
}

export async function directAiExtract(
  images: { base64: string; mimeType: string }[],
  measurements: Measurements,
  signal?: AbortSignal
): Promise<DesignSpec> {
  const ai = getAiClient();
  const parts: any[] = [];

  images.forEach((img, idx) => {
    parts.push({ text: `img${idx + 1}` });
    parts.push({
      inlineData: {
        mimeType: img.mimeType || 'image/jpeg',
        data: img.base64,
      },
    });
  });

  parts.push({
    text: `MEASURED PALETTE AND DIMENSIONS:\n${JSON.stringify(measurements, null, 2)}`,
  });

  const res = await generateContentWithFallback(ai, {
    contents: [{ role: 'user', parts }],
    systemInstruction: EXTRACT_PROMPT,
  });

  const candidate = res.candidates?.[0];
  if (candidate?.finishReason === 'SAFETY' || res.promptFeedback?.blockReason) {
    throw new AppError('adult_or_unsafe');
  }

  const raw = cleanJsonResponse(res.text || '');
  let parsed: any;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new AppError('unreadable', 'AI response could not be parsed as JSON');
  }

  const validated = validateDesignSpec(parsed);
  if (!validated.success || !validated.data) {
    throw new AppError('unreadable', `DesignSpec schema error: ${validated.errors?.join(', ')}`);
  }

  return validated.data;
}

/**
 * Universal client/server caller:
 * In browser: calls Express backend endpoints /api/ai/analyze and /api/ai/extract
 * In Node / Server: executes directAiAnalyze / directAiExtract
 */
export async function callAiAnalyze(
  images: { base64: string; mimeType?: string }[],
  signal: AbortSignal,
  onRetry: (seconds: number, attempt: number) => void
): Promise<AnalyzeResult> {
  return withRetry(async () => {
    if (typeof window !== 'undefined') {
      const resp = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ images }),
        signal,
      });

      if (!resp.ok) {
        const errorJson = await resp.json().catch(() => ({}));
        throw new AppError(errorJson.code || 'network', errorJson.message);
      }

      const data = await resp.json();
      const validated = validateAnalyzeResult(data);
      if (!validated.success || !validated.data) {
        throw new AppError('unreadable', 'Validation error from analyze endpoint');
      }
      return validated.data;
    } else {
      return directAiAnalyze(images as any, signal);
    }
  }, signal, onRetry);
}

export async function callAiExtract(
  images: { base64: string; mimeType?: string }[],
  measurements: Measurements,
  signal: AbortSignal,
  onRetry: (seconds: number, attempt: number) => void
): Promise<DesignSpec> {
  return withRetry(async () => {
    if (typeof window !== 'undefined') {
      const resp = await fetch('/api/ai/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ images, measurements }),
        signal,
      });

      if (!resp.ok) {
        const errorJson = await resp.json().catch(() => ({}));
        throw new AppError(errorJson.code || 'network', errorJson.message);
      }

      const data = await resp.json();
      const validated = validateDesignSpec(data);
      if (!validated.success || !validated.data) {
        throw new AppError('unreadable', 'Validation error from extract endpoint');
      }
      return validated.data;
    } else {
      return directAiExtract(images as any, measurements, signal);
    }
  }, signal, onRetry);
}
